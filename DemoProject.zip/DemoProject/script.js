// Example JavaScript functionality
document.addEventListener('DOMContentLoaded', function() {
    console.log("Website Loaded");
    // Add any JS functionality here if needed in the future
});
